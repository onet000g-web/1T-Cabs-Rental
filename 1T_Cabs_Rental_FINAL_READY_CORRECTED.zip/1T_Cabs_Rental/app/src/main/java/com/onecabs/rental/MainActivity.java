package com.onecabs.rental;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int TEAL = Color.rgb(11,110,105);
    private final List<TollRow> tolls = new ArrayList<>();
    private LinearLayout box;
    private LinearLayout tollContainer;
    private EditText customer, vehicle, contact, from, to, departure, returning, carRent;
    private TextView totalLabel;

    int dp(float v){ return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView text(String s, float size, int color, boolean bold){
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(4),dp(4),dp(4),dp(4));
        return t;
    }

    EditText field(String hint){
        EditText e = new EditText(this);
        e.setHint(hint); e.setSingleLine(true); e.setTextSize(16);
        e.setPadding(dp(12),0,dp(12),0);
        e.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(52)));
        return e;
    }

    Button textButton(String s){
        Button b = new Button(this);
        b.setText(s); b.setTextSize(16); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundColor(TEAL);
        return b;
    }

    @Override public void onCreate(Bundle b){ super.onCreate(b); showForm(); }

    private void showForm(){
        tolls.clear();
        LinearLayout root = baseRoot();
        ScrollView sv = new ScrollView(this);
        box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(16),dp(16),dp(24));
        box.addView(text("Create New Bill",24,Color.rgb(30,30,30),true));

        customer = field("Customer Name"); vehicle = field("Vehicle Number"); contact = field("Contact Number");
        from = field("Trip From"); to = field("Trip To");
        departure = field("Departure Date / Time"); returning = field("Return Date / Time");
        carRent = field("Car Rent (per 24 hours)");
        box.addView(customer); box.addView(vehicle); box.addView(contact); box.addView(from); box.addView(to);
        box.addView(departure); box.addView(returning); box.addView(carRent);

        box.addView(text("Toll Plazas",18,TEAL,true));
        tollContainer = new LinearLayout(this); tollContainer.setOrientation(LinearLayout.VERTICAL);
        box.addView(tollContainer);

        Button add = textButton("Add Toll Plaza");
        box.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));
        totalLabel = text("Toll Total: ₹0\nGrand Total: ₹0",18,Color.rgb(30,30,30),true);
        totalLabel.setGravity(Gravity.END); box.addView(totalLabel);
        Button preview = textButton("Preview Bill"); box.addView(preview,new LinearLayout.LayoutParams(-1,dp(52)));

        add.setOnClickListener(v -> addTollRow());
        preview.setOnClickListener(v -> showPreview());
        sv.addView(box); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private LinearLayout baseRoot(){
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        TextView head=text("1T Cabs & Rental",22,Color.WHITE,true); head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(16),0,dp(16),0); head.setBackgroundColor(TEAL);
        root.addView(head,new LinearLayout.LayoutParams(-1,dp(64))); return root;
    }

    private void addTollRow(){
        TollRow row = new TollRow(); tolls.add(row);
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(8),dp(8),dp(8),dp(8));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.rgb(245,248,248)); bg.setStroke(dp(1),Color.LTGRAY); bg.setCornerRadius(dp(8)); card.setBackground(bg);
        TextView title=text("Toll Plaza " + tolls.size(),17,TEAL,true); card.addView(title);
        row.name=field("Toll Name"); row.going=field("Going Time"); row.back=field("Return Time"); row.amount=field("Toll Amount");
        card.addView(row.name); card.addView(row.going); card.addView(row.back);
        row.type=new Spinner(this); String[] types={"Single + Single","Return Trip","Local Pass"};
        row.type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));
        card.addView(row.type,new LinearLayout.LayoutParams(-1,dp(52)));
        card.addView(row.amount);
        Button remove=textButton("Remove Toll"); card.addView(remove,new LinearLayout.LayoutParams(-1,dp(46)));
        remove.setOnClickListener(v -> { tollContainer.removeView(card); tolls.remove(row); refreshTollTitles(); updateTotals(); });
        tollContainer.addView(card,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));
        row.amount.setOnFocusChangeListener((v,has)->{ if(!has) updateTotals(); });
        row.amount.setOnKeyListener((v,key,event)->{ updateTotals(); return false; });
        updateTotals();
    }

    private void refreshTollTitles(){
        for(int i=0;i<tollContainer.getChildCount();i++){
            View child=tollContainer.getChildAt(i); if(child instanceof LinearLayout){ View first=((LinearLayout)child).getChildAt(0); if(first instanceof TextView) ((TextView)first).setText("Toll Plaza "+(i+1)); }
        }
    }

    private double number(EditText e){
        try { return Double.parseDouble(e.getText().toString().trim()); } catch(Exception ex){ return 0; }
    }

    private void updateTotals(){
        if(totalLabel==null) return;
        double toll=0; for(TollRow r:tolls) toll += number(r.amount);
        double rent=number(carRent); totalLabel.setText("Toll Total: ₹"+money(toll)+"\nGrand Total: ₹"+money(toll+rent));
    }

    private String money(double n){ return String.format(Locale.US,"%.0f",n); }

    private void showPreview(){
        double toll=0; for(TollRow r:tolls) toll+=number(r.amount); double rent=number(carRent); double grand=rent+toll;
        LinearLayout root=baseRoot(); ScrollView sv=new ScrollView(this); LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(18),dp(18),dp(18),dp(24));
        p.addView(text("BILL PREVIEW",24,TEAL,true));
        addLine(p,"Customer",customer.getText().toString()); addLine(p,"Vehicle Number",vehicle.getText().toString()); addLine(p,"Contact",contact.getText().toString());
        addLine(p,"Trip",from.getText().toString()+" → "+to.getText().toString()); addLine(p,"Departure",departure.getText().toString()); addLine(p,"Return",returning.getText().toString());
        p.addView(text("TOLL DETAILS",18,TEAL,true));
        for(int i=0;i<tolls.size();i++){
            TollRow r=tolls.get(i); String type=r.type.getSelectedItem()==null?"":r.type.getSelectedItem().toString();
            addLine(p,"Toll "+(i+1),r.name.getText().toString()+" | "+type+" | ₹"+money(number(r.amount)));
            addLine(p,"Times",r.going.getText().toString()+" / "+r.back.getText().toString());
        }
        addLine(p,"Car Rent","₹"+money(rent)); addLine(p,"Toll Total","₹"+money(toll));
        TextView grandView=text("GRAND TOTAL: ₹"+money(grand),22,Color.WHITE,true); grandView.setGravity(Gravity.CENTER); grandView.setPadding(dp(8),dp(14),dp(8),dp(14)); grandView.setBackgroundColor(TEAL); p.addView(grandView,new LinearLayout.LayoutParams(-1,dp(60)));
        Button back=textButton("Edit Bill"); back.setOnClickListener(v->showFormWithData()); p.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
        sv.addView(p); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void addLine(LinearLayout p,String a,String b){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,dp(5),0,dp(5));
        TextView l=text(a,15,Color.DKGRAY,true); TextView r=text(b,15,Color.BLACK,false); row.addView(l,new LinearLayout.LayoutParams(dp(130),-2)); row.addView(r,new LinearLayout.LayoutParams(0,-2,1)); p.addView(row);
    }

    private void showFormWithData(){
        final String c=customer.getText().toString(), v=vehicle.getText().toString(), co=contact.getText().toString(), f=from.getText().toString(), t=to.getText().toString();
        final String d=departure.getText().toString(), rt=returning.getText().toString(), cr=carRent.getText().toString();
        final List<TollData> td=new ArrayList<>(); for(TollRow r:tolls){ TollData x=new TollData(); x.n=r.name.getText().toString(); x.g=r.going.getText().toString(); x.b=r.back.getText().toString(); x.a=r.amount.getText().toString(); x.type=r.type.getSelectedItemPosition(); td.add(x); }
        showForm(); customer.setText(c); vehicle.setText(v); contact.setText(co); from.setText(f); to.setText(t); departure.setText(d); returning.setText(rt); carRent.setText(cr);
        for(TollData x:td){ addTollRow(); TollRow r=tolls.get(tolls.size()-1); r.name.setText(x.n); r.going.setText(x.g); r.back.setText(x.b); r.amount.setText(x.a); r.type.setSelection(x.type); } updateTotals();
    }

    private static class TollRow { EditText name,going,back,amount; Spinner type; }
    private static class TollData { String n,g,b,a; int type; }
}
