package com.onecabs.rental;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int TEAL = Color.rgb(11,110,105);
    private LinearLayout tollContainer;
    private TextView tollTotalView;
    private EditText customer, vehicle, contact, from, to, departure, returning, carRent;
    private final ArrayList<Toll> tolls = new ArrayList<>();

    static class Toll {
        String name, going, coming, journey, amount;
        Toll(String n, String g, String c, String j, String a){name=n;going=g;coming=c;journey=j;amount=a;}
    }

    int dp(float v){ return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView text(String s, float size, int color, boolean bold){
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(4),dp(4),dp(4),dp(4));
        return t;
    }

    EditText field(String hint){
        EditText e=new EditText(this);
        e.setHint(hint); e.setSingleLine(true); e.setTextSize(16);
        e.setPadding(dp(12),0,dp(12),0);
        e.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(52)));
        return e;
    }

    Button textButton(String s){
        Button b=new Button(this);
        b.setText(s); b.setTextSize(16); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundColor(TEAL);
        return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        buildScreen();
    }

    private void buildScreen(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);

        TextView head=text("1T Cabs & Rental",22,Color.WHITE,true);
        head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(dp(16),0,dp(16),0);
        head.setBackgroundColor(TEAL);
        root.addView(head,new LinearLayout.LayoutParams(-1,dp(64)));

        ScrollView sv=new ScrollView(this);
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(16),dp(16),dp(28));

        box.addView(text("Create New Bill",24,Color.rgb(30,30,30),true));
        customer=field("Customer Name"); vehicle=field("Vehicle Number"); contact=field("Contact Number");
        from=field("Trip From"); to=field("Trip To");
        departure=field("Departure (date & time)"); returning=field("Return (date & time)");
        carRent=field("Car Rent (per 24 hours)"); carRent.setInputType(2|8192);

        box.addView(customer); box.addView(vehicle); box.addView(contact);
        box.addView(from); box.addView(to); box.addView(departure); box.addView(returning); box.addView(carRent);

        TextView tollTitle=text("Toll Plazas",19,Color.rgb(30,30,30),true);
        tollTitle.setPadding(dp(4),dp(12),dp(4),dp(4)); box.addView(tollTitle);

        tollContainer=new LinearLayout(this); tollContainer.setOrientation(LinearLayout.VERTICAL);
        box.addView(tollContainer);

        Button add=textButton("Add Toll Plaza");
        add.setOnClickListener(v -> showTollDialog());
        box.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));

        tollTotalView=text("Toll Total: ₹0",18,Color.rgb(11,110,105),true);
        tollTotalView.setGravity(Gravity.RIGHT); tollTotalView.setPadding(0,dp(10),dp(4),dp(6));
        box.addView(tollTotalView);

        Button preview=textButton("Preview Bill");
        preview.setOnClickListener(v -> showPreview());
        box.addView(preview,new LinearLayout.LayoutParams(-1,dp(52)));

        sv.addView(box); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private void showTollDialog(){
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(8),0,dp(8),0);
        EditText name=field("Toll Name"); EditText going=field("Going time"); EditText coming=field("Return time");
        EditText amount=field("Toll Amount (₹)"); amount.setInputType(2|8192);
        Spinner journey=new Spinner(this);
        String[] options={"Single + Single","Return Trip","Local Pass"};
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options);
        journey.setAdapter(adapter);
        form.addView(name); form.addView(going); form.addView(coming); form.addView(journey); form.addView(amount);

        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("Add Toll Plaza").setView(form)
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Add",null).create();
        dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n=name.getText().toString().trim();
            String a=amount.getText().toString().trim();
            if(n.isEmpty() || a.isEmpty()){
                Toast.makeText(this,"Toll Name aur Amount bharna zaroori hai",Toast.LENGTH_SHORT).show();
                return;
            }
            tolls.add(new Toll(n,going.getText().toString().trim(),coming.getText().toString().trim(),journey.getSelectedItem().toString(),a));
            refreshTolls(); dialog.dismiss();
        }));
        dialog.show();
    }

    private void refreshTolls(){
        tollContainer.removeAllViews();
        for(int i=0;i<tolls.size();i++){
            final int index=i; Toll t=tolls.get(i);
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6),dp(5),dp(2),dp(5));
            TextView info=text((i+1)+". "+t.name+"\n"+t.journey+"\n"+t.going+" → "+t.coming+"\n₹"+t.amount,15,Color.DKGRAY,false);
            row.addView(info,new LinearLayout.LayoutParams(0,dp(92),1));
            Button del=new Button(this); del.setText("×"); del.setTextSize(20); del.setAllCaps(false);
            del.setOnClickListener(v->{tolls.remove(index);refreshTolls();});
            row.addView(del,new LinearLayout.LayoutParams(dp(52),dp(52)));
            tollContainer.addView(row,new LinearLayout.LayoutParams(-1,dp(100)));
        }
        double total=0; for(Toll t:tolls){try{total+=Double.parseDouble(t.amount);}catch(Exception ignored){}}
        tollTotalView.setText("Toll Total: ₹"+money(total));
    }

    private double num(EditText e){ try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception ex){return 0;} }
    private String money(double n){return String.format(Locale.US,"%.0f",n);}

    private void showPreview(){
        StringBuilder sb=new StringBuilder();
        sb.append("Customer: ").append(customer.getText().toString()).append("\n");
        sb.append("Vehicle: ").append(vehicle.getText().toString()).append("\n");
        sb.append("Contact: ").append(contact.getText().toString()).append("\n");
        sb.append("Trip: ").append(from.getText().toString()).append(" → ").append(to.getText().toString()).append("\n");
        sb.append("Departure: ").append(departure.getText().toString()).append("\n");
        sb.append("Return: ").append(returning.getText().toString()).append("\n\n");
        sb.append("Car Rent / 24h: ₹").append(money(num(carRent))).append("\n");
        double tollTotal=0;
        for(int i=0;i<tolls.size();i++){
            Toll t=tolls.get(i); double a=0; try{a=Double.parseDouble(t.amount);}catch(Exception ignored){}
            tollTotal+=a; sb.append("Toll ").append(i+1).append(": ").append(t.name).append(" — ₹").append(money(a)).append("\n");
        }
        sb.append("\nToll Total: ₹").append(money(tollTotal));
        sb.append("\nGrand Total: ₹").append(money(num(carRent)+tollTotal));

        new AlertDialog.Builder(this).setTitle("Bill Preview").setMessage(sb.toString())
                .setPositiveButton("OK",null).show();
    }
}
