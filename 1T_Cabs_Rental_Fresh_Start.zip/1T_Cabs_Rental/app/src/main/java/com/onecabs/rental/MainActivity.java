package com.onecabs.rental;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    int dp(float v){ return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    TextView text(String s, float size, int color, boolean bold){
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(dp(4),dp(4),dp(4),dp(4)); return t;
    }
    EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextSize(16); e.setPadding(dp(12),0,dp(12),0); e.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(52))); return e; }
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        TextView head=text("1T Cabs & Rental",22,Color.WHITE,true); head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(dp(16),0,dp(16),0); head.setBackgroundColor(Color.rgb(11,110,105)); root.addView(head,new LinearLayout.LayoutParams(-1,dp(64)));
        ScrollView sv=new ScrollView(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(16),dp(16),dp(24));
        box.addView(text("Create New Bill",24,Color.rgb(30,30,30),true));
        box.addView(field("Customer Name")); box.addView(field("Vehicle Number")); box.addView(field("Contact Number")); box.addView(field("Trip From")); box.addView(field("Trip To"));
        box.addView(field("Car Rent (per 24 hours)"));
        Button add=textButton("Add Toll Plaza"); box.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));
        Button preview=textButton("Preview Bill"); box.addView(preview,new LinearLayout.LayoutParams(-1,dp(52)));
        add.setOnClickListener(v -> Toast.makeText(this,"Toll section will be added here",Toast.LENGTH_SHORT).show());
        preview.setOnClickListener(v -> Toast.makeText(this,"Bill preview coming next",Toast.LENGTH_SHORT).show());
        sv.addView(box); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    Button textButton(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.rgb(11,110,105)); return b; }
}
