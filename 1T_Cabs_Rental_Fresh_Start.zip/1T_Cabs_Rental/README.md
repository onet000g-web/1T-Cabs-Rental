# 1T Cabs & Rental — Fresh Android Project

Fresh Java Android project. The first milestone is a stable launchable APK; billing features will be added after launch is verified.
